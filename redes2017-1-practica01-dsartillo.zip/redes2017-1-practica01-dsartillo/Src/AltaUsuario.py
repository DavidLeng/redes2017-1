# -- Autor - David Sartillo Salazar || Leonardo Gallo Guerrero
# -- Fecha - 15/08/2016
# -- Clase que trabaja con la forma de alta de usuarios
 
import sys
from PyQt4 import QtCore, QtGui, uic
 
# Cargar archivo .ui
clase_Forma = uic.loadUiType("view/AltaUsuario.ui")[0]
 
class ClaseVentana(QtGui.QMainWindow, clase_Forma):
 def __init__(self, parent=None):
  QtGui.QMainWindow.__init__(self, parent)
  self.setupUi(self)
  self.AgregarUsuario.clicked.connect(self.AgregarUsuario_clicked)

 def AgregarUsuario_clicked(self):
  sUser = self.Usuario.text()
  sPass = self.Password.text()
  if(len(sUser) > 0 and len(sPass) > 0):
  	oArch = open("input.txt", "a")
  	passw = ""
  	for caracter in sPass:
  		passw += chr(ord(str(caracter)) + 5)
  	oArch.write("\n" + sUser + "|" + passw)
  	oArch.close()
  	self.destroy()
