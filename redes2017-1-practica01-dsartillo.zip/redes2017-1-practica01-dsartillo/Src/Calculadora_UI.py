# -- Autor - David Sartillo Salazar || Leonardo Gallo Guerrero
# -- Fecha - 15/08/2016
# -- Clase que trabaja con la calculadora
 
import sys
from PyQt4 import QtCore, QtGui, uic
from AltaUsuario import ClaseVentana
 
# Cargar archivo .ui
oForma = uic.loadUiType("view/Calculadora_UI.ui")[0]

#Variables globales
Operando1 = 0
Operando2 = 0
Operador = ""
 
class Calculadora(QtGui.QMainWindow, oForma):
 def __init__(self, parent=None):
  QtGui.QMainWindow.__init__(self, parent)
  self.setupUi(self)
  self.Num0.clicked.connect(self.Num0_clicked)
  self.Num1.clicked.connect(self.Num1_clicked)
  self.Num2.clicked.connect(self.Num2_clicked)
  self.Num3.clicked.connect(self.Num3_clicked)
  self.Num4.clicked.connect(self.Num4_clicked)
  self.Num5.clicked.connect(self.Num5_clicked)
  self.Num6.clicked.connect(self.Num6_clicked)
  self.Num7.clicked.connect(self.Num7_clicked)
  self.Num8.clicked.connect(self.Num8_clicked)
  self.Num9.clicked.connect(self.Num9_clicked)
  self.Suma.clicked.connect(self.Suma_clicked)
  self.Resta.clicked.connect(self.Resta_clicked)
  self.Producto.clicked.connect(self.Producto_clicked)
  self.Division.clicked.connect(self.Division_clicked)
  self.Punto.clicked.connect(self.Punto_clicked)
  self.Igual.clicked.connect(self.Igual_clicked)
  self.UsuarioNuevo.clicked.connect(self.UsuarioNuevo_clicked)
 
 def Num0_clicked(self):
  if(len(self.Resultado.text()) > 0):
    self.Resultado.setText(self.Resultado.text() + "0")

 def Num1_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "1")
 
 def Num2_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "2")

 def Num3_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "3")
 
 def Num4_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "4")

 def Num5_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "5")
 
 def Num6_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "6")

 def Num7_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "7")
 
 def Num8_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "8")

 def Num9_clicked(self):
  self.Resultado.setText(self.Resultado.text() + "9")

 def Punto_clicked(self):
  if(len(self.Resultado.text()) <= 0):
    self.Resultado.setText("0.")
  else :
    self.Resultado.setText(self.Resultado.text() + ".")
  
 def Suma_clicked(self):
  global Operador
  global Operando1
  if(len(Operador) <= 0):
    Operador = "+"
    Operando1 = self.Resultado.text()
    self.Resultado.setText("")
  else :
    self.Resultado.setText("")
    Operando1 = str(RealizarOperacion(Operando1, Operando2, Operador))
    Operador = "+"

 def Resta_clicked(self):
  global Operador
  global Operando1
  if(len(Operador) <= 0):
    Operador = "-"
    Operando1 = self.Resultado.text()
    self.Resultado.setText("")
  else :
    self.Resultado.setText("")
    Operando1 = str(RealizarOperacion(Operando1, Operando2, Operador))
    Operador = "-"

 def Division_clicked(self):
  global Operador
  global Operando1
  if(len(Operador) <= 0):
    Operador = "/"
    Operando1 = self.Resultado.text()
    self.Resultado.setText("")
  else :
    self.Resultado.setText("")
    Operando1 = str(RealizarOperacion(Operando1, Operando2, Operador))
    Operador = "/"

 def Producto_clicked(self):
  global Operador
  global Operando1
  if(len(Operador) <= 0):
    Operador = "*"
    Operando1 = self.Resultado.text()
    self.Resultado.setText("")
  else :
    self.Resultado.setText("")
    Operando1 = str(RealizarOperacion(Operando1, Operando2, Operador))
    Operador = "*"

 def Igual_clicked(self):
  global Operador
  global Operando1
  global Operando2
  Operando2 = self.Resultado.text()
  self.Resultado.setText(str(RealizarOperacion(Operando1, Operando2, Operador)))
  Operando1 = 0
  Operando2 = 0
  Operador = ""

 def UsuarioNuevo_clicked(self):
 	Ventana = ClaseVentana(self)
	Ventana.show()
  
 
def RealizarOperacion(numero1, numero2, operacion):
  if(operacion == "+"):
    return float(numero1) + float(numero2)
  elif (operacion == "-"):
    return float(numero1) - float(numero2)
  elif (operacion == "/"):
    return float(numero1) / float(numero2)
  elif (operacion == "*"):
    return float(numero1) * float(numero2)
  else :
    return float(numero2)
