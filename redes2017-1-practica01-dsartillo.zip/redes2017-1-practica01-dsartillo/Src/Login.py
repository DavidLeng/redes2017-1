# -- Autor - David Sartillo Salazar || Leonardo Gallo Guerrero
# -- Fecha - 15/08/2016
# -- Clase que trabaja con la ventana de login


import sys
from PyQt4 import QtCore, QtGui, uic
from Calculadora_UI import Calculadora
from Alerta import VetanaAlerta
 
# Cargar archivo .ui
oFormulario = uic.loadUiType("view/Login_UI.ui")[0]
 
class VentanaLogin(QtGui.QMainWindow, oFormulario):
 def __init__(self, parent=None):
  QtGui.QMainWindow.__init__(self, parent)
  self.setupUi(self)
  self.Ingresar.clicked.connect(self.Ingresar_clicked)
 
 def Ingresar_clicked(self):
  sUser = self.Usuario.text()
  sPass = self.Password.text()
  if(len(sUser) > 0 and len(sPass) > 0):
    if(ConsultaUsuario(sUser, sPass)):
      oCalculadora = Calculadora(self)
      oCalculadora.show()
    else :
      oMensaje = VetanaAlerta(self)
      oMensaje.show()
 
def ConsultaUsuario(usuario, contrasenia):
  oArchivo = open("input.txt", "r")
  sPassw = ""

  for caracter in contrasenia:
      sPassw += chr(ord(str(caracter)) + 5)

  oLinea = oArchivo.readline()
  while oLinea != "":
    oLinea = oLinea.strip()
    sDatos = oLinea.split("|")
    if(usuario == sDatos[0] and sPassw == sDatos[1]):
      oArchivo.close()
      oLinea = ""
      return True
    print(oLinea)
    oLinea = oArchivo.readline()
  oArchivo.close()
  return False

#Iniciando aplicacion
oApp = QtGui.QApplication(sys.argv)
Login = VentanaLogin(None)
Login.show()
oApp.exec_()
