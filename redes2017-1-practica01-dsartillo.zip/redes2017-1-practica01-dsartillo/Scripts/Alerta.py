# -- Autor - David Sartillo Salazar || Leonardo Gallo Guerrero
# -- Fecha - 15/08/2016
# -- Clase que trabaja con una alerta

import sys
from PyQt4 import QtCore, QtGui, uic
 
# Cargar archivo .ui
oFormulario = uic.loadUiType("view/Alerta_UI.ui")[0]
 
class VetanaAlerta(QtGui.QMainWindow, oFormulario):
 def __init__(self, parent=None):
  QtGui.QMainWindow.__init__(self, parent)
  self.setupUi(self)
  self.Aceptar.clicked.connect(self.Aceptar_clicked)
 
 def Aceptar_clicked(self):
  self.destroy()
